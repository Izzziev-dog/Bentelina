// Cart state
let cart = [];

// DOM Elements
let cartCount, cartItems, checkoutTotal;

// Initialize cart
function initCart() {
    cartCount = document.getElementById('cartCount');
    cartItems = document.getElementById('cartItems');
    checkoutTotal = document.getElementById('checkoutTotal');
    
    // Load cart from localStorage if available
    const savedCart = localStorage.getItem('bentelinaCart');
    if (savedCart) {
        cart = JSON.parse(savedCart);
        updateCartCount();
    }
}

// Add to cart
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const existingItem = cart.find(item => item.id === productId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            ...product,
            quantity: 1
        });
    }
    
    updateCartCount();
    saveCartToStorage();
    showNotification(`${product.name} добавлен в корзину!`);
}

// Update cart count
function updateCartCount() {
    if (!cartCount) return;
    
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;
    cartCount.setAttribute('aria-label', `Товаров в корзине: ${totalItems}`);
}

// Save cart to localStorage
function saveCartToStorage() {
    localStorage.setItem('bentelinaCart', JSON.stringify(cart));
}

// Render cart items
function renderCartItems() {
    if (!cartItems) return;
    
    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <h3>Корзина пуста</h3>
                <p>Добавьте товары в корзину для оформления заказа</p>
            </div>
            <div style="padding: 20px;">
                <button class="checkout-btn" onclick="closeModal(document.getElementById('cartModal'))" style="background: var(--primary);">
                    Продолжить покупки
                </button>
            </div>
        `;
        return;
    }

    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    cartItems.innerHTML = `
        ${cart.map(item => `
            <div class="cart-item">
                <div class="item-image">
                    <i class="${item.icon}"></i>
                </div>
                <div class="item-info">
                    <div class="item-name">${item.name}</div>
                    <div class="item-price">${item.price.toLocaleString()} ₽</div>
                </div>
                <div class="item-controls">
                    <button class="quantity-btn" onclick="updateQuantity(${item.id}, -1)" aria-label="Уменьшить количество">-</button>
                    <span class="item-quantity">${item.quantity}</span>
                    <button class="quantity-btn" onclick="updateQuantity(${item.id}, 1)" aria-label="Увеличить количество">+</button>
                </div>
                <button class="remove-item" onclick="removeFromCart(${item.id})" aria-label="Удалить товар">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `).join('')}
        
        <div class="cart-total">
            <span>Итого:</span>
            <span class="total-amount">${total.toLocaleString()} ₽</span>
        </div>
        
        <button class="checkout-btn" onclick="openCheckout()">
            Оформить заказ
        </button>
    `;
}

// Update quantity
function updateQuantity(productId, change) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        item.quantity += change;
        if (item.quantity <= 0) {
            cart = cart.filter(item => item.id !== productId);
        }
        updateCartCount();
        renderCartItems();
        saveCartToStorage();
    }
}

// Remove from cart
function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    updateCartCount();
    renderCartItems();
    saveCartToStorage();
    showNotification('Товар удален из корзины');
}

// Open checkout
function openCheckout() {
    if (cart.length === 0) return;
    
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    checkoutTotal.textContent = `${total.toLocaleString()} ₽`;
    
    closeModal(document.getElementById('cartModal'));
    openModal(document.getElementById('checkoutModal'));
}

// Export functions for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { 
        initCart, 
        addToCart, 
        updateCartCount, 
        renderCartItems, 
        updateQuantity, 
        removeFromCart, 
        openCheckout 
    };
}