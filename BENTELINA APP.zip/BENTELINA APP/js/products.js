// Product data with categories and detailed descriptions
const products = [
    // ЖЕНСКИЕ АРОМАТЫ
    {
        id: 1,
        name: "Chanel Coco Mademoiselle",
        description: "Элегантный цветочно-восточный аромат, воплощающий современную женственность",
        detailedDescription: "Изысканный парфюм открывается свежими нотами апельсина и бергамота, переходя в сердце из жасмина и розы, и завершается теплыми аккордами пачули и ветивера.",
        volume: "50 мл",
        price: 12400,
        icon: "fas fa-diamond",
        category: "women",
        season: ["spring", "summer"],
        time: "day",
        intensity: "medium",
        notes: {
            top: ["Апельсин", "Бергамот", "Мандарин"],
            middle: ["Жасмин", "Роза", "Мимоза"],
            base: ["Пачули", "Ветивер", "Ваниль"]
        },
        occasion: "повседневный, офис, свидание",
        longevity: "6-8 часов"
    },
    {
        id: 2,
        name: "Yves Saint Laurent Black Opium",
        description: "Смелый кофейно-ванильный аромат для современных женщин",
        detailedDescription: "Наркотически притягательный парфюм начинается с всплеска грушевой ноты, раскрывается ароматом кофе и апельсинового цвета, и закрепляется ванилью и кедром.",
        volume: "50 мл",
        price: 11200,
        icon: "fas fa-coffee",
        category: "women",
        season: ["autumn", "winter"],
        time: "evening",
        intensity: "strong",
        notes: {
            top: ["Груша", "Розовый перец", "Апельсиновый цвет"],
            middle: ["Кофе", "Жасмин", "Лакрица"],
            base: ["Ваниль", "Кедр", "Патчоли"]
        },
        occasion: "вечерний выход, клуб, особые события",
        longevity: "8-10 часов"
    },
    {
        id: 3,
        name: "Gucci Bloom",
        description: "Цветочный букет, напоминающий о весеннем саду",
        detailedDescription: "Нежный и женственный аромат создает иллюзию прогулки по цветущему саду с нотами туберозы, жасмина и редкого растения рангунской лианы.",
        volume: "75 мл",
        price: 9800,
        icon: "fas fa-seedling",
        category: "women",
        season: ["spring", "summer"],
        time: "day",
        intensity: "light",
        notes: {
            top: ["Рангунская лиана"],
            middle: ["Тубероза", "Жасмин самбак"],
            base: ["Орхидея", "Мускус"]
        },
        occasion: "дневной, прогулки, свидания",
        longevity: "4-6 часов"
    },

    // МУЖСКИЕ АРОМАТЫ
    {
        id: 101,
        name: "Dior Sauvage",
        description: "Свежий и дикий аромат современного мужчины",
        detailedDescription: "Мощный и свежий парфюм начинается с нотами калабрийского бергамота, раскрывается пряным аккордом перца и лаванды, и завершается амброй и кедром.",
        volume: "100 мл",
        price: 8900,
        icon: "fas fa-wind",
        category: "men",
        season: ["spring", "summer"],
        time: "day",
        intensity: "medium",
        notes: {
            top: ["Калабрийский бергамот"],
            middle: ["Сычуаньский перец", "Лаванда"],
            base: ["Амбра", "Кедр", "Аккорд амброксана"]
        },
        occasion: "повседневный, офис, активный отдых",
        longevity: "7-9 часов"
    },
    {
        id: 102,
        name: "Creed Aventus",
        description: "Легендарный аромат для победителей",
        detailedDescription: "Богатый и сложный парфюм открывается нотами черной смородины и бергамота, переходит в сердце из жасмина и березового дерева, и завершается мускусом и дубовым мхом.",
        volume: "100 мл",
        price: 24500,
        icon: "fas fa-crown",
        category: "men",
        season: ["all"],
        time: "evening",
        intensity: "strong",
        notes: {
            top: ["Черная смородина", "Бергамот", "Яблоко"],
            middle: ["Жасмин", "Береза", "Роза"],
            base: ["Мускус", "Дубовый мох", "Амбра"]
        },
        occasion: "деловые встречи, вечерние события, особые случаи",
        longevity: "10-12 часов"
    },

    // УНИСЕКС АРОМАТЫ
    {
        id: 201,
        name: "Tom Ford Oud Wood",
        description: "Роскошный древесно-восточный аромат",
        detailedDescription: "Изысканная композиция сочетает редкое дерево уд с нотами сандала, ветивера и бобов тонка, создавая теплый и загадочный шлейф.",
        volume: "100 мл",
        price: 18700,
        icon: "fas fa-tree",
        category: "unisex",
        season: ["autumn", "winter"],
        time: "evening",
        intensity: "strong",
        notes: {
            top: ["Кардамон", "Розовое дерево"],
            middle: ["Уд", "Сандал", "Ветивер"],
            base: ["Бобы тонка", "Амбра", "Ваниль"]
        },
        occasion: "вечерние мероприятия, особые случаи",
        longevity: "10-14 часов"
    },
    {
        id: 202,
        name: "Jo Malone Wood Sage & Sea Salt",
        description: "Свежий морской бриз с древесными нотами",
        detailedDescription: "Аромат, напоминающий о прогулке по побережью: соленый морской воздух смешивается с древесными нотами шалфея и кедра.",
        volume: "100 мл",
        price: 7600,
        icon: "fas fa-water",
        category: "unisex",
        season: ["spring", "summer"],
        time: "day",
        intensity: "light",
        notes: {
            top: ["Морская соль", "Редберри"],
            middle: ["Шалфей"],
            base: ["Кедр", "Амбра"]
        },
        occasion: "повседневный, отдых, спорт",
        longevity: "4-5 часов"
    },

    // НИШЕВЫЕ АРОМАТЫ
    {
        id: 301,
        name: "Maison Francis Kurkdjian Baccarat Rouge 540",
        description: "Роскошный амброво-древесный шедевр",
        detailedDescription: "Исключительный парфюм создан в честь 250-летия бренда Baccarat. Сочетает шафран, жасмин и амбру с кедром и мускусом.",
        volume: "70 мл",
        price: 28900,
        icon: "fas fa-gem",
        category: "niche",
        season: ["autumn", "winter"],
        time: "evening",
        intensity: "strong",
        notes: {
            top: ["Шафран", "Жасмин"],
            middle: ["Амбра", "Древесные ноты"],
            base: ["Кедр", "Мускус", "Миндаль"]
        },
        occasion: "особые события, вечерние приемы",
        longevity: "12-15 часов"
    },
    {
        id: 302,
        name: "Le Labo Santal 33",
        description: "Культовый сандаловый аромат с кожаными нотами",
        detailedDescription: "Знаковый парфюм сочетает австралийский сандал с нотами кардамона, ирисa и кожи, создавая современный ковбойский образ.",
        volume: "100 мл",
        price: 21300,
        icon: "fas fa-feather",
        category: "niche",
        season: ["all"],
        time: "all",
        intensity: "medium",
        notes: {
            top: ["Кардамон", "Ирис", "Фиалка"],
            middle: ["Австралийский сандал", "Кедр"],
            base: ["Кожа", "Мускус", "Амбра"]
        },
        occasion: "повседневный, творческая работа, встречи",
        longevity: "8-10 часов"
    }
];

// Category information
const categories = {
    women: { name: "Женские", icon: "fas fa-venus", color: "#ff69b4" },
    men: { name: "Мужские", icon: "fas fa-mars", color: "#4169e1" },
    unisex: { name: "Унисекс", icon: "fas fa-venus-mars", color: "#9370db" },
    niche: { name: "Нишевые", icon: "fas fa-star", color: "#ffd700" }
};

// Filter options
const filters = {
    season: {
        spring: { name: "Весна", icon: "fas fa-leaf" },
        summer: { name: "Лето", icon: "fas fa-sun" },
        autumn: { name: "Осень", icon: "fas fa-tree" },
        winter: { name: "Зима", icon: "fas fa-snowflake" },
        all: { name: "Любой сезон", icon: "fas fa-infinity" }
    },
    time: {
        day: { name: "Дневной", icon: "fas fa-sun" },
        evening: { name: "Вечерний", icon: "fas fa-moon" },
        all: { name: "Любое время", icon: "fas fa-clock" }
    },
    intensity: {
        light: { name: "Легкий", icon: "fas fa-feather" },
        medium: { name: "Средний", icon: "fas fa-balance-scale" },
        strong: { name: "Стойкий", icon: "fas fa-fire" }
    }
};

// Current filter state
let currentFilters = {
    category: 'all',
    season: 'all',
    time: 'all',
    intensity: 'all'
};

// Initialize products with filters
function initProducts() {
    renderCategoryFilters();
    renderProducts();
    setupFilterListeners();
}

// Render category filters
function renderCategoryFilters() {
    const filtersContainer = document.getElementById('categoryFilters');
    if (!filtersContainer) return;
    
    filtersContainer.innerHTML = `
        <div class="category-filter ${currentFilters.category === 'all' ? 'active' : ''}" data-category="all">
            <i class="fas fa-all"></i>
            <span>Все ароматы</span>
        </div>
        ${Object.entries(categories).map(([key, category]) => `
            <div class="category-filter ${currentFilters.category === key ? 'active' : ''}" data-category="${key}">
                <i class="${category.icon}"></i>
                <span>${category.name}</span>
            </div>
        `).join('')}
    `;
}

// Render advanced filters
function renderAdvancedFilters() {
    const filtersContainer = document.getElementById('advancedFilters');
    if (!filtersContainer) return;
    
    filtersContainer.innerHTML = `
        <div class="filter-group">
            <h4>Сезон</h4>
            ${Object.entries(filters.season).map(([key, filter]) => `
                <button class="filter-btn ${currentFilters.season === key ? 'active' : ''}" data-type="season" data-value="${key}">
                    <i class="${filter.icon}"></i>
                    ${filter.name}
                </button>
            `).join('')}
        </div>
        
        <div class="filter-group">
            <h4>Время дня</h4>
            ${Object.entries(filters.time).map(([key, filter]) => `
                <button class="filter-btn ${currentFilters.time === key ? 'active' : ''}" data-type="time" data-value="${key}">
                    <i class="${filter.icon}"></i>
                    ${filter.name}
                </button>
            `).join('')}
        </div>
        
        <div class="filter-group">
            <h4>Стойкость</h4>
            ${Object.entries(filters.intensity).map(([key, filter]) => `
                <button class="filter-btn ${currentFilters.intensity === key ? 'active' : ''}" data-type="intensity" data-value="${key}">
                    <i class="${filter.icon}"></i>
                    ${filter.name}
                </button>
            `).join('')}
        </div>
        
        <button class="clear-filters" onclick="clearFilters()">
            <i class="fas fa-times"></i>
            Сбросить фильтры
        </button>
    `;
}

// Setup filter listeners
function setupFilterListeners() {
    // Category filters
    document.querySelectorAll('.category-filter').forEach(filter => {
        filter.addEventListener('click', function() {
            currentFilters.category = this.dataset.category;
            renderCategoryFilters();
            renderProducts();
        });
    });
    
    // Advanced filters
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('filter-btn')) {
            const type = e.target.dataset.type;
            const value = e.target.dataset.value;
            
            currentFilters[type] = currentFilters[type] === value ? 'all' : value;
            renderAdvancedFilters();
            renderProducts();
        }
    });
}

// Clear all filters
function clearFilters() {
    currentFilters = {
        category: 'all',
        season: 'all',
        time: 'all',
        intensity: 'all'
    };
    renderCategoryFilters();
    renderAdvancedFilters();
    renderProducts();
}

// Filter products based on current filters
function filterProducts() {
    return products.filter(product => {
        // Category filter
        if (currentFilters.category !== 'all' && product.category !== currentFilters.category) {
            return false;
        }
        
        // Season filter
        if (currentFilters.season !== 'all' && !product.season.includes(currentFilters.season)) {
            return false;
        }
        
        // Time filter
        if (currentFilters.time !== 'all' && product.time !== currentFilters.time && product.time !== 'all') {
            return false;
        }
        
        // Intensity filter
        if (currentFilters.intensity !== 'all' && product.intensity !== currentFilters.intensity) {
            return false;
        }
        
        return true;
    });
}

// Render products based on filters
function renderProducts() {
    const productsGrid = document.getElementById('productsGrid');
    if (!productsGrid) return;
    
    const filteredProducts = filterProducts();
    
    if (filteredProducts.length === 0) {
        productsGrid.innerHTML = `
            <div class="no-products">
                <i class="fas fa-search"></i>
                <h3>Ничего не найдено</h3>
                <p>Попробуйте изменить параметры фильтрации</p>
                <button class="clear-filters" onclick="clearFilters()">
                    Сбросить фильтры
                </button>
            </div>
        `;
        return;
    }
    
    productsGrid.innerHTML = filteredProducts.map(product => {
        const category = categories[product.category];
        return `
            <div class="product-card" onclick="showProductDetails(${product.id})">
                <div class="product-image" style="background: linear-gradient(45deg, ${category.color}20, ${category.color}40)">
                    <i class="${product.icon}"></i>
                    <div class="product-badge" style="background: ${category.color}">
                        ${category.name}
                    </div>
                </div>
                <div class="product-info">
                    <h3 class="product-name">${product.name}</h3>
                    <p class="product-description">${product.description}</p>
                    
                    <div class="product-meta">
                        <span class="product-volume">${product.volume}</span>
                        <div class="product-tags">
                            <span class="product-tag">
                                <i class="${filters.season[product.season[0]]?.icon || 'fas fa-leaf'}"></i>
                                ${product.season.map(s => filters.season[s]?.name).join(', ')}
                            </span>
                            <span class="product-tag">
                                <i class="${filters.time[product.time]?.icon || 'fas fa-clock'}"></i>
                                ${filters.time[product.time]?.name}
                            </span>
                        </div>
                    </div>
                    
                    <div class="product-price">${product.price.toLocaleString()} ₽</div>
                    <button class="add-to-cart" onclick="event.stopPropagation(); addToCart(${product.id})">
                        <i class="fas fa-cart-plus"></i> В корзину
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

// Show product details modal
function showProductDetails(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const category = categories[product.category];
    
    const modal = document.createElement('div');
    modal.className = 'product-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal()">&times;</span>
            
            <div class="modal-header">
                <div class="modal-image" style="background: linear-gradient(45deg, ${category.color}20, ${category.color}40)">
                    <i class="${product.icon}"></i>
                </div>
                <div class="modal-title">
                    <h2>${product.name}</h2>
                    <span class="product-category" style="color: ${category.color}">
                        <i class="${category.icon}"></i> ${category.name}
                    </span>
                </div>
            </div>
            
            <div class="modal-body">
                <div class="product-description-section">
                    <h3>Описание</h3>
                    <p>${product.detailedDescription}</p>
                </div>
                
                <div class="product-notes-section">
                    <h3>Ноты аромата</h3>
                    <div class="notes-grid">
                        <div class="note-type">
                            <h4>Верхние ноты</h4>
                            <div class="note-list">
                                ${product.notes.top.map(note => `<span class="note">${note}</span>`).join('')}
                            </div>
                        </div>
                        <div class="note-type">
                            <h4>Ноты сердца</h4>
                            <div class="note-list">
                                ${product.notes.middle.map(note => `<span class="note">${note}</span>`).join('')}
                            </div>
                        </div>
                        <div class="note-type">
                            <h4>Базовые ноты</h4>
                            <div class="note-list">
                                ${product.notes.base.map(note => `<span class="note">${note}</span>`).join('')}
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="product-specs">
                    <div class="spec">
                        <i class="fas fa-clock"></i>
                        <span>Стойкость: ${product.longevity}</span>
                    </div>
                    <div class="spec">
                        <i class="fas fa-calendar"></i>
                        <span>Сезон: ${product.season.map(s => filters.season[s]?.name).join(', ')}</span>
                    </div>
                    <div class="spec">
                        <i class="fas fa-sun"></i>
                        <span>Время: ${filters.time[product.time]?.name}</span>
                    </div>
                    <div class="spec">
                        <i class="fas fa-glass-cheers"></i>
                        <span>Повод: ${product.occasion}</span>
                    </div>
                </div>
            </div>
            
            <div class="modal-footer">
                <div class="modal-price">${product.price.toLocaleString()} ₽</div>
                <button class="add-to-cart-large" onclick="addToCart(${product.id}); closeModal()">
                    <i class="fas fa-cart-plus"></i> Добавить в корзину
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    document.body.style.overflow = 'hidden';
}

// Close modal
function closeModal() {
    const modal = document.querySelector('.product-modal');
    if (modal) {
        document.body.removeChild(modal);
        document.body.style.overflow = 'auto';
    }
}

// Add to cart function
function addToCart(productId) {
    // Здесь будет логика добавления в корзину
    console.log('Добавлен в корзину:', productId);
    alert('Товар добавлен в корзину!');
}

// Toggle advanced filters
function toggleAdvancedFilters() {
    const filtersSection = document.getElementById('advancedFiltersSection');
    const toggleBtn = document.querySelector('.toggle-filters');
    
    filtersSection.classList.toggle('hidden');
    toggleBtn.innerHTML = filtersSection.classList.contains('hidden') ? 
        '<i class="fas fa-sliders-h"></i> Показать фильтры' : 
        '<i class="fas fa-times"></i> Скрыть фильтры';
    
    if (!filtersSection.classList.contains('hidden')) {
        renderAdvancedFilters();
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initProducts();
});

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { products, categories, filters, initProducts };
}