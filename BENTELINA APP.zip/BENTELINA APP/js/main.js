// DOM Elements
let cartModal, checkoutModal, closeCartModal, closeCheckoutModal, checkoutForm;
let deliveryMethod, pickupTimeGroup, addressGroup, shippingCompanyGroup;

// Initialize application
function initApp() {
    // Initialize modules
    initProducts();
    initCart();
    
    // Get DOM elements
    cartModal = document.getElementById('cartModal');
    checkoutModal = document.getElementById('checkoutModal');
    closeCartModal = document.getElementById('closeCartModal');
    closeCheckoutModal = document.getElementById('closeCheckoutModal');
    checkoutForm = document.getElementById('checkoutForm');
    deliveryMethod = document.getElementById('deliveryMethod');
    pickupTimeGroup = document.getElementById('pickupTimeGroup');
    addressGroup = document.getElementById('addressGroup');
    shippingCompanyGroup = document.getElementById('shippingCompanyGroup');
    
    // Set up event listeners
    setupEventListeners();
    
    // Set default delivery method
    setDefaultDeliveryMethod();
}

// Set up event listeners
function setupEventListeners() {
    // Cart button
    const cartButton = document.getElementById('cartButton');
    if (cartButton) {
        cartButton.addEventListener('click', openCartModal);
    }
    
    // Close modal buttons
    if (closeCartModal) {
        closeCartModal.addEventListener('click', () => closeModal(cartModal));
    }
    
    if (closeCheckoutModal) {
        closeCheckoutModal.addEventListener('click', () => closeModal(checkoutModal));
    }
    
    // Close modals on outside click
    window.addEventListener('click', (event) => {
        if (event.target === cartModal) {
            closeModal(cartModal);
        }
        if (event.target === checkoutModal) {
            closeModal(checkoutModal);
        }
    });
    
    // Close modals on Escape key
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            if (cartModal.style.display === 'flex') {
                closeModal(cartModal);
            }
            if (checkoutModal.style.display === 'flex') {
                closeModal(checkoutModal);
            }
        }
    });
    
    // Delivery options
    setupDeliveryOptions();
    
    // Checkout form submission
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', handleCheckoutSubmit);
    }
    
    // Smooth scrolling for hero button
    const heroBtn = document.querySelector('.hero-btn');
    if (heroBtn) {
        heroBtn.addEventListener('click', () => {
            document.getElementById('products').scrollIntoView({ 
                behavior: 'smooth' 
            });
        });
    }
}

// Set up delivery options
function setupDeliveryOptions() {
    const deliveryOptions = document.querySelectorAll('.delivery-option');
    deliveryOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove selected class from all options
            deliveryOptions.forEach(opt => {
                opt.classList.remove('selected');
            });
            
            // Add selected class to clicked option
            this.classList.add('selected');
            
            // Update hidden input value
            const method = this.dataset.method;
            deliveryMethod.value = method;
            
            // Show/hide relevant fields
            updateDeliveryFields(method);
        });
    });
}

// Update delivery fields based on selected method
function updateDeliveryFields(method) {
    // Pickup time
    pickupTimeGroup.classList.toggle('hidden', method !== 'pickup');
    
    // Address (for postal, cdek, dpd)
    addressGroup.classList.toggle('hidden', !['postal', 'cdek', 'dpd'].includes(method));
    
    // Shipping company (for ozon)
    shippingCompanyGroup.classList.toggle('hidden', method !== 'ozon');
    
    // Set required attributes
    const addressInput = document.getElementById('address');
    const shippingCompanyInput = document.getElementById('shippingCompany');
    
    if (['postal', 'cdek', 'dpd'].includes(method)) {
        addressInput.setAttribute('required', 'true');
    } else {
        addressInput.removeAttribute('required');
    }
    
    if (method === 'ozon') {
        shippingCompanyInput.setAttribute('required', 'true');
    } else {
        shippingCompanyInput.removeAttribute('required');
    }
}

// Set default delivery method
function setDefaultDeliveryMethod() {
    const defaultOption = document.querySelector('.delivery-option[data-method="pickup"]');
    if (defaultOption) {
        defaultOption.classList.add('selected');
        deliveryMethod.value = 'pickup';
        updateDeliveryFields('pickup');
    }
}

// Open modal
function openModal(modal) {
    if (modal === cartModal) {
        renderCartItems();
    }
    modal.style.display = 'flex';
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    
    // Focus trap for accessibility
    trapFocus(modal);
}

// Close modal
function closeModal(modal) {
    modal.style.display = 'none';
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = 'auto';
}

// Focus trap for modal accessibility
function trapFocus(modal) {
    const focusableElements = modal.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    
    if (focusableElements.length > 0) {
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];
        
        firstElement.focus();
        
        modal.addEventListener('keydown', function(e) {
            if (e.key === 'Tab') {
                if (e.shiftKey) {
                    if (document.activeElement === firstElement) {
                        e.preventDefault();
                        lastElement.focus();
                    }
                } else {
                    if (document.activeElement === lastElement) {
                        e.preventDefault();
                        firstElement.focus();
                    }
                }
            }
        });
    }
}

// Open cart modal
function openCartModal() {
    openModal(cartModal);
}

// Handle checkout form submission
function handleCheckoutSubmit(e) {
    e.preventDefault();
    
    const phone = document.getElementById('phone').value;
    const phoneRegex = /^(\+7|7|8)?[\s\-]?\(?[489][0-9]{2}\)?[\s\-]?[0-9]{3}[\s\-]?[0-9]{2}[\s\-]?[0-9]{2}$/;
    
    // Validate phone number
    if (!phoneRegex.test(phone)) {
        showNotification('Пожалуйста, введите корректный номер телефона', 'error');
        return;
    }
    
    // Validate delivery method specific fields
    const deliveryMethodValue = deliveryMethod.value;
    const pickupTime = document.getElementById('pickupTime').value;
    const address = document.getElementById('address').value;
    const shippingCompany = document.getElementById('shippingCompany').value;
    
    if (deliveryMethodValue === 'pickup' && !pickupTime) {
        showNotification('Пожалуйста, укажите время самовывоза', 'error');
        return;
    }
    
    if (['postal', 'cdek', 'dpd'].includes(deliveryMethodValue) && !address) {
        showNotification('Пожалуйста, укажите адрес доставки', 'error');
        return;
    }
    
    if (deliveryMethodValue === 'ozon' && !shippingCompany) {
        showNotification('Пожалуйста, укажите транспортную компанию', 'error');
        return;
    }
    
    // Prepare order details
    const orderDetails = prepareOrderDetails();
    const deliveryInfo = prepareDeliveryInfo(deliveryMethodValue, pickupTime, address, shippingCompany);
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    // Create WhatsApp message
    const message = createWhatsAppMessage(orderDetails, total, phone, deliveryInfo, address);
    
    // Send to WhatsApp
    sendToWhatsApp(message);
    
    // Clear cart and close modal
    clearCart();
    closeModal(checkoutModal);
    
    showNotification('Заказ отправлен в WhatsApp!');
}

// Prepare order details
function prepareOrderDetails() {
    return cart.map(item => 
        `${item.name} (${item.volume}) x ${item.quantity} = ${item.price * item.quantity} руб.`
    ).join('\n');
}

// Prepare delivery information
function prepareDeliveryInfo(method, pickupTime, address, shippingCompany) {
    switch(method) {
        case 'pickup':
            return `Самовывоз в ${pickupTime || 'уточнить'}`;
        case 'postal':
            return 'Почтовая отправка (Почта России)';
        case 'cdek':
            return 'Доставка через СДЭК';
        case 'ozon':
            return `Доставка через Ozon${shippingCompany ? ` (${shippingCompany})` : ''}`;
        case 'dpd':
            return 'Доставка через DPD';
        default:
            return 'Не указано';
    }
}

// Create WhatsApp message
function createWhatsAppMessage(orderDetails, total, phone, deliveryInfo, address) {
    const addressInfo = address ? `\nАдрес: ${address}` : '';
    
    return `Заказ в BENTELINA\n\n${orderDetails}\n\nИтого: ${total} руб.\n\nКонтакт: ${phone}\nДоставка: ${deliveryInfo}${addressInfo}`;
}

// Send to WhatsApp
function sendToWhatsApp(message) {
    const whatsappUrl = `https://wa.me/79172468822?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
}

// Clear cart
function clearCart() {
    cart = [];
    updateCartCount();
    renderCartItems();
    saveCartToStorage();
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', initApp);

// Export functions for use in other files if needed
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { 
        initApp, 
        openModal, 
        closeModal, 
        handleCheckoutSubmit 
    };
}